﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace CarDetailProject
{
    /// <summary>
    /// carD.xaml etkileşim mantığı
    /// </summary>
    public partial class carD : Window
    {
        public carD()
        {
            InitializeComponent();
            LoadCarDetails("06DOR50");
        }

        private void LoadCarDetails(string numberPlate)
        {
            // Connection string from configuration file
            string connectionString = ConfigurationManager.ConnectionStrings["CarDetailProject.Properties.Settings.flamingoRentConnectionString"].ConnectionString;

            // SQL query to fetch data
            string query = "SELECT * FROM CAR WHERE NUMBER_PLATE = @NumberPlate";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@NumberPlate", numberPlate);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                // Populate textboxes with data from the database
                                PLAKABOX.Text = reader["NUMBER_PLATE"].ToString();
                                TYPEBOX.Text = reader["VEHICLE_TYPE"].ToString();
                                YEARBOX.Text = reader["YEAR"].ToString();
                                FUELBOX.Text = reader["FUEL_TYPE"].ToString();
                                GEARBOX.Text = reader["GEAR_TYPE"].ToString();
                                MODELBOX.Text = reader["MODEL"].ToString();
                                BRANDBOX.Text = reader["BRAND"].ToString();
                                COLORBOX.Text = reader["COLOR"].ToString();
                                KMBOX.Text = reader["KILOMETER"].ToString();
                                AVBOX.IsChecked = reader["AVAILABILITY"] != DBNull.Value && (bool)reader["AVAILABILITY"];
                                CAPACITYBOX.Text = reader["SEATING_CAPACITY"].ToString();
                                PRICEBOX.Text = reader["RENT_PRICE"].ToString();
                            }
                            else
                            {
                                MessageBox.Show("Car details not found.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            // Connection string from configuration file
            string connectionString = ConfigurationManager.ConnectionStrings["CarDetailProject.Properties.Settings.flamingoRentConnectionString"].ConnectionString;

            // SQL query to update data
            string query = @"UPDATE CAR
                             SET VEHICLE_TYPE = @VehicleType,
                                 YEAR = @Year,
                                 FUEL_TYPE = @FuelType,
                                 GEAR_TYPE = @GearType,
                                 MODEL = @Model,
                                 BRAND = @Brand,
                                 COLOR = @Color,
                                 KILOMETER = @Kilometer,
                                 AVAILABILITY = @Availability,
                                 SEATING_CAPACITY = @SeatingCapacity,
                                 RENT_PRICE = @RentPrice
                             WHERE NUMBER_PLATE = @NumberPlate";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters to the query
                        command.Parameters.AddWithValue("@NumberPlate", PLAKABOX.Text);
                        command.Parameters.AddWithValue("@VehicleType", TYPEBOX.Text);
                        command.Parameters.AddWithValue("@Year", int.TryParse(YEARBOX.Text, out int year) ? year : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@FuelType", FUELBOX.Text);
                        command.Parameters.AddWithValue("@GearType", GEARBOX.Text);
                        command.Parameters.AddWithValue("@Model", MODELBOX.Text);
                        command.Parameters.AddWithValue("@Brand", BRANDBOX.Text);
                        command.Parameters.AddWithValue("@Color", COLORBOX.Text);
                        command.Parameters.AddWithValue("@Kilometer", int.TryParse(KMBOX.Text, out int kilometer) ? kilometer : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Availability", AVBOX.IsChecked ?? false);
                        command.Parameters.AddWithValue("@SeatingCapacity", int.TryParse(CAPACITYBOX.Text, out int capacity) ? capacity : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@RentPrice", PRICEBOX.Text);

                        // Execute the update query
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Car details updated successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        else
                        {
                            MessageBox.Show("No record was updated. Please check the number plate.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }









        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_2(object sender, TextChangedEventArgs e)
        {

        }

        private void MODELBOX_Kopyala_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
      
        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }
    }
}
