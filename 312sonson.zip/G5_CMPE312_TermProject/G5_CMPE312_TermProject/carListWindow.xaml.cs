﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace G5_CMPE312_TermProject
{
    /// <summary>
    /// Interaction logic for carListWindow.xaml
    /// </summary>
    public partial class carListWindow : Window
    {
        SqlConnection sqlConnection;
        public carListWindow()
        {
            InitializeComponent();
            string connectionString = ConfigurationManager.ConnectionStrings["G5_CMPE312_TermProject.Properties.Settings.flamingoRentConnectionString"].ConnectionString;
            sqlConnection = new SqlConnection(connectionString);
            FillCarListBox();
        }

        public class Car
        {
            public ImageSource CarImage { get; set; }
            public string Brand { get; set; }
            public string Model { get; set; }
            public int Year { get; set; }
            public decimal Price { get; set; }
            public string NumPlate { get; set; }
        }

        List<Car> cars;
        private void FillCarListBox()
        {
            cars = new List<Car>();
            string query = "SELECT CAR_IMAGE, BRAND, MODEL, YEAR, RENT_PRICE, NUMBER_PLATE FROM CAR";

            try
            {
                sqlConnection.Open();
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                SqlDataReader reader = sqlCommand.ExecuteReader();

                while (reader.Read())
                {
                    Car car = new Car
                    {
                        CarImage = reader["CAR_IMAGE"] != DBNull.Value
                            ? LoadImage((byte[])reader["CAR_IMAGE"])
                            : null,
                        Brand = reader["BRAND"].ToString(),
                        Model = reader["MODEL"].ToString(),
                        Year = Convert.ToInt32(reader["YEAR"]),
                        Price = Convert.ToDecimal(reader["RENT_PRICE"]),
                        NumPlate = reader["NUMBER_PLATE"].ToString()
                    };

                    cars.Add(car);
                }
            }
            catch (Exception e)
            {
                MessageBox.Show($"Error: {e.Message}");
            }
            finally
            {
                sqlConnection.Close();
            }

            CarListBox.ItemsSource = cars; // Bind the car list to the ListBox
        }
        private ImageSource LoadImage(byte[] imageData)
        {
            using (MemoryStream stream = new MemoryStream(imageData))
            {
                BitmapImage image = new BitmapImage();
                image.BeginInit();
                image.CacheOption = BitmapCacheOption.OnLoad;
                image.StreamSource = stream;
                image.EndInit();
                return image;
            }
        }



        private void ClickableImage_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            addCarWindow addCar2 = new addCarWindow();
            addCar2.Show();
            this.Hide();
        }

        private void GoBack_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //if we have hidden kullaniciYon before, find that one and show it, if not create new instance
            kullaniciYon kullYon = Application.Current.Windows.OfType<kullaniciYon>().FirstOrDefault();
            if (kullYon != null)
            {
                kullYon.Show();
                this.Hide();
            }
            else
            {
                kullaniciYon kullYonIns = new kullaniciYon();
                kullYonIns.Show();
                this.Hide();
            }
        }
        

        private void CarListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedCar = CarListBox.SelectedItem as Car;
            if (selectedCar != null)
            {
                string numberPlate = selectedCar.NumPlate;
                carUpdateDetail crUpDeWin = new carUpdateDetail(numberPlate);
                crUpDeWin.Show();
                CarListBox.SelectedItem = null;
            }
        }

        //when refresh the car list clicked
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            cars.Clear();
            FillCarListBox();
        }
    }
}
