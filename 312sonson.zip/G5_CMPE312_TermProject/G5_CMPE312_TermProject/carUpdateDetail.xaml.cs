﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace G5_CMPE312_TermProject
{
    /// <summary>
    /// Interaction logic for carUpdateDetail.xaml
    /// </summary>
    public partial class carUpdateDetail : Window
    {
        public carUpdateDetail(string numPlate)
        {
            InitializeComponent();
            LoadCarDetails(numPlate);
        }

        private void LoadCarDetails(string numberPlate)
        {
            // Connection string from configuration file
            string connectionString = ConfigurationManager.ConnectionStrings["G5_CMPE312_TermProject.Properties.Settings.flamingoRentConnectionString"].ConnectionString;

            // SQL query to fetch data
            string query = "SELECT * FROM CAR WHERE NUMBER_PLATE = @NumberPlate";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@NumberPlate", numberPlate);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                // Populate textboxes with data from the database
                                PLAKABOX.Text = reader["NUMBER_PLATE"].ToString();
                                TYPEBOX.Text = reader["VEHICLE_TYPE"].ToString();
                                YEARBOX.Text = reader["YEAR"].ToString();
                                FUELBOX.Text = reader["FUEL_TYPE"].ToString();
                                GEARBOX.Text = reader["GEAR_TYPE"].ToString();
                                MODELBOX.Text = reader["MODEL"].ToString();
                                BRANDBOX.Text = reader["BRAND"].ToString();
                                COLORBOX.Text = reader["COLOR"].ToString();
                                KMBOX.Text = reader["KILOMETER"].ToString();
                                AVBOX.IsChecked = reader["AVAILABILITY"] != DBNull.Value && (bool)reader["AVAILABILITY"];
                                CAPACITYBOX.Text = reader["SEATING_CAPACITY"].ToString();
                                PRICEBOX.Text = reader["RENT_PRICE"].ToString();
                                NAMEBOX.Text = reader["rentPersonNameSurname"].ToString();
                                STARTBOX.Text = reader["rentStartDate"].ToString();
                                ENDBOX.Text = reader["rentEndDate"].ToString();

                                // Load image if available
                                if (reader["CAR_IMAGE"] != DBNull.Value)
                                {
                                    byte[] imageBytes = (byte[])reader["CAR_IMAGE"];
                                    BitmapImage bitmapImage = ByteArrayToBitmapImage(imageBytes);

                                    // Set image in the UI
                                    BackgroundImageBrush.ImageSource = bitmapImage;
                                    DetailImage.Source = bitmapImage;
                                }
                                else
                                {
                                    MessageBox.Show("No image available for this car.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
                                }
                            }
                            else
                            {
                                MessageBox.Show("Car details not found.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        // Helper method to convert byte[] to BitmapImage
        private BitmapImage ByteArrayToBitmapImage(byte[] imageBytes)
        {
            using (MemoryStream stream = new MemoryStream(imageBytes))
            {
                BitmapImage bitmapImage = new BitmapImage();
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = stream;
                bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                bitmapImage.EndInit();
                return bitmapImage;
            }
        }


        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            // Connection string from configuration file
            string connectionString = ConfigurationManager.ConnectionStrings["G5_CMPE312_TermProject.Properties.Settings.flamingoRentConnectionString"].ConnectionString;

            // SQL query to update data
            string query = @"UPDATE CAR
                             SET VEHICLE_TYPE = @VehicleType,
                                 YEAR = @Year,
                                 FUEL_TYPE = @FuelType,
                                 GEAR_TYPE = @GearType,
                                 MODEL = @Model,
                                 BRAND = @Brand,
                                 COLOR = @Color,
                                 KILOMETER = @Kilometer,
                                 AVAILABILITY = @Availability,
                                 SEATING_CAPACITY = @SeatingCapacity,
                                 RENT_PRICE = @RentPrice,
                                 rentPersonNameSurname = @PersonName,
                                 rentStartDate = @StartDate,
                                 rentEndDate = @EndDate
                             WHERE NUMBER_PLATE = @NumberPlate";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters to the query
                        command.Parameters.AddWithValue("@NumberPlate", PLAKABOX.Text);
                        command.Parameters.AddWithValue("@VehicleType", TYPEBOX.Text);
                        command.Parameters.AddWithValue("@Year", int.TryParse(YEARBOX.Text, out int year) ? year : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@FuelType", FUELBOX.Text);
                        command.Parameters.AddWithValue("@GearType", GEARBOX.Text);
                        command.Parameters.AddWithValue("@Model", MODELBOX.Text);
                        command.Parameters.AddWithValue("@Brand", BRANDBOX.Text);
                        command.Parameters.AddWithValue("@Color", COLORBOX.Text);
                        command.Parameters.AddWithValue("@Kilometer", int.TryParse(KMBOX.Text, out int kilometer) ? kilometer : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@Availability", AVBOX.IsChecked ?? false);
                        command.Parameters.AddWithValue("@SeatingCapacity", int.TryParse(CAPACITYBOX.Text, out int capacity) ? capacity : (object)DBNull.Value);
                        command.Parameters.AddWithValue("@RentPrice", PRICEBOX.Text);
                        command.Parameters.AddWithValue("@PersonName", NAMEBOX.Text);
                        command.Parameters.AddWithValue("@StartDate", STARTBOX.Text);
                        command.Parameters.AddWithValue("@EndDate", ENDBOX.Text);

                        // Execute the update query
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Car details updated successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        else
                        {
                            MessageBox.Show("No record was updated. Please check the number plate.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void GoBack_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.Close();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_1(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBox_TextChanged_2(object sender, TextChangedEventArgs e)
        {

        }

        private void MODELBOX_Kopyala_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {

        }


        //when delete the car is clicked
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Are you sure you want to delete this car?", "Confirm Deletion", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (result == MessageBoxResult.Yes)
            {
                // Get the number plate from the text box or another source
                string numberPlate = PLAKABOX.Text;

                if (!string.IsNullOrEmpty(numberPlate))
                {
                    DeleteCar(numberPlate);
                }
                else
                {
                    MessageBox.Show("Please select a car to delete.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        private void DeleteCar(string numberPlate)
        {
            // Connection string from configuration file
            string connectionString = ConfigurationManager.ConnectionStrings["G5_CMPE312_TermProject.Properties.Settings.flamingoRentConnectionString"].ConnectionString;

            // SQL query to delete the car
            string query = "DELETE FROM CAR WHERE NUMBER_PLATE = @NumberPlate";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@NumberPlate", numberPlate);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Car deleted successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                        else
                        {
                            MessageBox.Show("Car not found. Deletion failed.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

    }
}
