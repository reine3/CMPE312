﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace G5_CMPE312_TermProject
{
    /// <summary>
    /// Interaction logic for kullaniciYon.xaml
    /// </summary>
    public partial class kullaniciYon : Window
    {
        public kullaniciYon()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            carListWindow crList = new carListWindow();
            crList.Show();
            this.Hide();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            //if we have hidden addCarWindow before, find that one and show it, if not create new instance
            addCarWindow addCar = Application.Current.Windows.OfType<addCarWindow>().FirstOrDefault();
            if (addCar != null)
            {
                addCar.Show();
                this.Hide();
            }
            else
            {
                addCarWindow addCar2 = new addCarWindow();
                addCar2.Show();
                this.Hide();
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
