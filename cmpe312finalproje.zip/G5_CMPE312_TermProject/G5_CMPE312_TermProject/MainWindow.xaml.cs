﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace G5_CMPE312_TermProject
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string connectionString;
        
        public MainWindow()
        {
            InitializeComponent();
            connectionString = ConfigurationManager.ConnectionStrings["G5_CMPE312_TermProject.Properties.Settings.flamingoRentConnectionString"].ConnectionString;
            
        }

        private void CheckUsername_Click(object sender, RoutedEventArgs e)
        {
            string username = usernametextbox.Text.Trim();
            string password = passwordtextbox.Text.Trim();
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both username and password.");
                return;
            }

            try
            {
                SqlConnection connection = new SqlConnection(connectionString);
                using (connection)
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM [dbo].[USER] WHERE userName = @userName AND PASSWORD = @password";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@userName", username);
                        command.Parameters.AddWithValue("@password", password);

                        int userCount = (int)command.ExecuteScalar();

                        if (userCount > 0)
                        {
                            kullaniciYon kullanıcıYönEkranı = new kullaniciYon(); // Doğru sınıf adıyla nesne oluşturun.
                            kullanıcıYönEkranı.Show(); // Yeni pencereyi göster
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Incorrect username or password!");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }
    }

}
