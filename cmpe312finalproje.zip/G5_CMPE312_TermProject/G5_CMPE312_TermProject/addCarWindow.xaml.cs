﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Input;
using System.Linq;

namespace G5_CMPE312_TermProject
{
    /// <summary>
    /// Interaction logic for addCarWindow.xaml
    /// </summary>
    public partial class addCarWindow : Window
    {
        public addCarWindow()
        {
            InitializeComponent();
            AddItems();
            // Marka ComboBox'ını doldur
            foreach (var brand in carData.Keys)
            {
                brandBox.Items.Add(brand);
            }
            IsAllBoxChoosen();
        }
        private Dictionary<string, List<string>> carData = new Dictionary<string, List<string>>()
        {
            { "Toyota", new List<string> { "Corolla", "Camry", "Yaris" } },
            { "Ford", new List<string> { "Focus", "Fiesta", "Mustang" } },
            { "BMW", new List<string> { "3 Series", "5 Series", "X5" } },
            { "Mercedes-Benz", new List<string> { "C-Class", "E-Class", "GLA" } },
            { "Honda", new List<string> { "Civic", "Accord", "CR-V" } },
            { "Nissan", new List<string> { "Altima", "Rogue", "GT-R" } },
            { "Hyundai", new List<string> { "Elantra", "Tucson", "Santa Fe" } },
            { "Kia", new List<string> { "Rio", "Sportage", "Sorento" } },
            { "Volkswagen", new List<string> { "Golf", "Passat", "Tiguan" } },
            { "Chevrolet", new List<string> { "Cruze", "Malibu", "Tahoe" } },
            { "Tesla", new List<string> { "Model S", "Model 3", "Model X" } },
            { "Mazda", new List<string> { "Mazda3", "Mazda6", "CX-5" } },
            { "Subaru", new List<string> { "Impreza", "Outback", "Forester" } },
            { "Lexus", new List<string> { "RX", "NX", "ES" } },
            { "Ferrari", new List<string> { "488", "Portofino", "SF90" } },
            { "Lamborghini", new List<string> { "Huracán", "Aventador", "Urus" } },
            { "Volvo", new List<string> { "XC40", "XC60", "S90" } },
            { "Audi", new List<string> { "A3", "A4", "Q5" } },
            { "Porsche", new List<string> { "911", "Cayenne", "Panamera" } },
            { "Jeep", new List<string> { "Wrangler", "Cherokee", "Grand Cherokee" } }
        };

        public void IsAllBoxChoosen()
        {
            // ComboBox'lardan seçim yapılıp yapılmadığını ve TextBox'ların boş olup olmadığını kontrol et
            if (brandBox.SelectedIndex == -1 || modelBox.SelectedIndex == -1 ||
                string.IsNullOrWhiteSpace(yearBox.Text) || string.IsNullOrWhiteSpace(kmBox.Text) ||
                string.IsNullOrWhiteSpace(numberPlateBox.Text) || locationBox.SelectedIndex == -1 ||
                fuelTypeBox.SelectedIndex == -1 || gearTypeBox.SelectedIndex == -1 ||
                colorBox.SelectedIndex == -1 || seatingBox.SelectedIndex == -1 ||
                vehicleTypeBox.SelectedIndex == -1 || vehicleConditionBox.SelectedIndex == -1 ||
                string.IsNullOrWhiteSpace(priceBox.Text))

            {
                label2.Content = "Lütfen tüm ComboBox'ları ve TextBox'ları doldurun!";
                button3.Visibility = Visibility.Hidden;
            }
            else
            {
                label2.Content = string.Empty;
                button3.Visibility = Visibility.Visible;
            }
        }


        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            modelBox.Items.Clear();

            if (brandBox.SelectedItem != null)
            {
                string selectedBrand = brandBox.SelectedItem.ToString();

                if (carData.ContainsKey(selectedBrand))
                {
                    foreach (var model in carData[selectedBrand])
                    {
                        modelBox.Items.Add(model);
                    }
                }
            }
            IsAllBoxChoosen();
        }

        private void addPictureButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Title = "Bir resim seçin",
                Filter = "Resim Dosyaları|*.jpg;*.jpeg;*.png;*.bmp;*.gif"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                BitmapImage bitmap = new BitmapImage(new Uri(filePath));
                uploadImage.Source = bitmap;
            }
        }
        private void AddItems()
        {
            fuelTypeBox.Items.Add("Petrol");
            fuelTypeBox.Items.Add("Diesel");
            fuelTypeBox.Items.Add("Electric");
            fuelTypeBox.Items.Add("Hybrid");

            gearTypeBox.Items.Add("Manual Transmission");
            gearTypeBox.Items.Add("Automatic Transmission");
            gearTypeBox.Items.Add("Continuously Variable Transmission");
            gearTypeBox.Items.Add("Dual-Clutch Transmission");
            gearTypeBox.Items.Add("Automated Manual Transmission");
            gearTypeBox.Items.Add("Tiptronic Transmission");

            colorBox.Items.Add("White");
            colorBox.Items.Add("Black");
            colorBox.Items.Add("Gray/Metallic Gray");
            colorBox.Items.Add("Red");
            colorBox.Items.Add("Blue");
            colorBox.Items.Add("Green");
            colorBox.Items.Add("Yellow/Gold");

            seatingBox.Items.Add("2");
            seatingBox.Items.Add("4");
            seatingBox.Items.Add("5");
            seatingBox.Items.Add("7");
            seatingBox.Items.Add("8");
            seatingBox.Items.Add("9+");

            vehicleTypeBox.Items.Add("Sedan");
            vehicleTypeBox.Items.Add("Hatchback");
            vehicleTypeBox.Items.Add("Coupe");
            vehicleTypeBox.Items.Add("Convertible");
            vehicleTypeBox.Items.Add("SUV");
            vehicleTypeBox.Items.Add("Crossover");
            vehicleTypeBox.Items.Add("Minivan");
            vehicleTypeBox.Items.Add("Pickup Truck");
            vehicleTypeBox.Items.Add("Electric Vehicle");
            vehicleTypeBox.Items.Add("Hybrid Vehicle");

            vehicleConditionBox.Items.Add("Brand New");
            vehicleConditionBox.Items.Add("Pre-owned");
            vehicleConditionBox.Items.Add("Total Loss");
            vehicleConditionBox.Items.Add("Good");
            vehicleConditionBox.Items.Add("Fair");
            vehicleConditionBox.Items.Add("Poor");

            locationBox.Items.Add("Ankara");
            locationBox.Items.Add("İstanbul");
            locationBox.Items.Add("İzmir");
            locationBox.Items.Add("Antalya");
            locationBox.Items.Add("Balıkesir");

        }

        private void fuelTypeBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            IsAllBoxChoosen();
        }

        private void GoBack_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //if we have hidden kullaniciYon before, find that one and show it, if not create new instance
            kullaniciYon kullYon = Application.Current.Windows.OfType<kullaniciYon>().FirstOrDefault();
            if (kullYon != null)
            {
                kullYon.Show();
                this.Hide();
            }
            else
            {
                kullaniciYon kullYonIns = new kullaniciYon();
                kullYonIns.Show();
                this.Hide();
            }
        }

        private void locationBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            IsAllBoxChoosen();
        }

        private void yearBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            IsAllBoxChoosen();
        }

        private void kmBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            IsAllBoxChoosen();
        }

        private void gearTypeBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            IsAllBoxChoosen();
        }

        private void colorBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            IsAllBoxChoosen();
        }

        private void seatingBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            IsAllBoxChoosen();
        }

        private void numberPlateBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            IsAllBoxChoosen();
        }

        private void vehicleTypeBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            IsAllBoxChoosen();
        }

        private void vehicleConditionBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            IsAllBoxChoosen();
        }

        private void priceBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            IsAllBoxChoosen();
        }

        public void UploadCarData()
        {
            try
            {
                // Connection string
                string connectionString = ConfigurationManager.ConnectionStrings["G5_CMPE312_TermProject.Properties.Settings.flamingoRentConnectionString"].ConnectionString;

                // Create a SQL connection
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    // Open the connection
                    connection.Open();

                    // SQL command to insert data
                    string query = "INSERT INTO [dbo].[CAR] ([NUMBER_PLATE], [VEHICLE_TYPE], [YEAR], [FUEL_TYPE], [GEAR_TYPE], [MODEL], [BRAND], [LOCATION_ID], [CONDITION_NOTES], [COLOR], [KILOMETER], [AVAILABILITY], [SEATING_CAPACITY], [CAR_IMAGE], [RENT_PRICE]) VALUES (@NUMBER_PLATE, @VEHICLE_TYPE, @YEAR, @FUEL_TYPE, @GEAR_TYPE, @MODEL, @BRAND, @LOCATION_ID, @CONDITION_NOTES, @COLOR, @KILOMETER, @AVAILABILITY, @SEATING_CAPACITY, @CAR_IMAGE, @RENT_PRICE)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        // Add parameters from the WPF UI
                        command.Parameters.AddWithValue("@NUMBER_PLATE", numberPlateBox.Text);
                        command.Parameters.AddWithValue("@VEHICLE_TYPE", vehicleTypeBox.Text);
                        command.Parameters.AddWithValue("@YEAR", int.Parse(yearBox.Text));
                        command.Parameters.AddWithValue("@FUEL_TYPE", fuelTypeBox.Text);
                        command.Parameters.AddWithValue("@GEAR_TYPE", gearTypeBox.Text);
                        command.Parameters.AddWithValue("@MODEL", modelBox.Text);
                        command.Parameters.AddWithValue("@BRAND", brandBox.Text);
                        command.Parameters.AddWithValue("@LOCATION_ID", 1);
                        command.Parameters.AddWithValue("@CONDITION_NOTES", vehicleConditionBox.Text);
                        command.Parameters.AddWithValue("@COLOR", colorBox.Text);
                        command.Parameters.AddWithValue("@KILOMETER", int.Parse(kmBox.Text));
                        command.Parameters.AddWithValue("@AVAILABILITY", true); // Assuming availability is always true for new entries
                        command.Parameters.AddWithValue("@SEATING_CAPACITY", int.Parse(seatingBox.Text));
                        command.Parameters.AddWithValue("@RENT_PRICE", priceBox.Text);

                        // Convert uploaded image to byte array
                        if (uploadImage.Source != null)
                        {
                            BitmapImage bitmapImage = (BitmapImage)uploadImage.Source;
                            byte[] imageData;
                            using (MemoryStream stream = new MemoryStream())
                            {
                                BitmapEncoder encoder = new PngBitmapEncoder();
                                encoder.Frames.Add(BitmapFrame.Create(bitmapImage));
                                encoder.Save(stream);
                                imageData = stream.ToArray();
                            }
                            command.Parameters.AddWithValue("@CAR_IMAGE", imageData);
                        }
                        else
                        {
                            command.Parameters.AddWithValue("@CAR_IMAGE", DBNull.Value);
                        }

                        // Execute the command
                        command.ExecuteNonQuery();

                        MessageBox.Show("Car data uploaded successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            UploadCarData();
        }
    }
}
